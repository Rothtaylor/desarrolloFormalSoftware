import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

enum Rol { ESTUDIANTE, DOCENTE, DIRECTOR }

enum Estado {
    PENDIENTE_DE_EVALUACION("pendiente de evaluación"),
    PENDIENTE_DE_PAGO("pendiente de pago"),
    RECHAZADA("Rechazada");

    final String texto;
    Estado(String texto) { this.texto = texto; }
    @Override public String toString() { return texto; }
}

class Usuario {
    final String nombre, correo;
    final Rol rol;
    boolean activo = true, sesionIniciada = true;

    Usuario(String nombre, String correo, Rol rol) {
        this.nombre = nombre; this.correo = correo; this.rol = rol;
    }
}

class Solicitud {
    final int id;
    final Usuario estudiante;
    final String asignatura, archivoExcusa;
    final LocalDate fechaEvaluacion, fechaSolicitud;
    Estado estado = Estado.PENDIENTE_DE_EVALUACION;
    Double calificacion; // null hasta que se evalúe

    Solicitud(int id, Usuario estudiante, String asignatura, LocalDate fechaEvaluacion,
              LocalDate fechaSolicitud, String archivoExcusa) {
        this.id = id; this.estudiante = estudiante; this.asignatura = asignatura;
        this.fechaEvaluacion = fechaEvaluacion; this.fechaSolicitud = fechaSolicitud;
        this.archivoExcusa = archivoExcusa;
    }
}

/** Funcionalidades: Realizar solicitud (RF2.1, RF2.7), Consultar estado y Evaluar solicitud (RF2.4). */
public class SupletoriosService {
    static final int PLAZO_MAX_DIAS_HABILES = 5;
    static final int MAX_SOLICITUDES_POR_ASIGNATURA = 2;
    // Festivos de ejemplo (Colombia 2026). Verificar contra el calendario oficial.
    static final Set<LocalDate> FESTIVOS = Set.of(
            LocalDate.of(2026, 7, 20), LocalDate.of(2026, 8, 7), LocalDate.of(2026, 8, 17),
            LocalDate.of(2026, 10, 12), LocalDate.of(2026, 11, 2), LocalDate.of(2026, 11, 16),
            LocalDate.of(2026, 12, 8), LocalDate.of(2026, 12, 25));

    final List<Solicitud> solicitudes = new ArrayList<>();
    final List<String> correos = new ArrayList<>(); // correos institucionales "enviados"
    private int siguienteId = 1;

    // ---------- Contratos ----------
    private static void pre(boolean cumple, String msg) {
        if (!cumple) throw new IllegalArgumentException("Precondición no cumplida: " + msg);
    }

    private static void post(boolean cumple, String msg) {
        if (!cumple) throw new IllegalStateException("Postcondición violada: " + msg);
    }

    // ---------- Días hábiles (evita el defecto de contar días calendario) ----------
    static boolean esHabil(LocalDate d) {
        return d.getDayOfWeek() != DayOfWeek.SATURDAY
                && d.getDayOfWeek() != DayOfWeek.SUNDAY
                && !FESTIVOS.contains(d);
    }

    /** Días hábiles transcurridos después de 'desde' hasta 'hasta' (inclusive). */
    static int diasHabiles(LocalDate desde, LocalDate hasta) {
        int n = 0;
        for (LocalDate d = desde.plusDays(1); !d.isAfter(hasta); d = d.plusDays(1)) {
            if (esHabil(d)) n++;
        }
        return n;
    }

    Solicitud buscar(int id) {
        return solicitudes.stream().filter(s -> s.id == id).findFirst().orElse(null);
    }

    int contarSolicitudes(Usuario u, String asignatura) {
        return (int) solicitudes.stream()
                .filter(s -> s.estudiante == u && s.asignatura.equalsIgnoreCase(asignatura.trim()))
                .count();
    }

    // ---------- Funcionalidad 1: Realizar solicitud de supletorio ----------
    /**
     * PRE: (1) estudiante con cuenta activa y sesión iniciada; (2) datos obligatorios completos;
     *      (3) excusa en PDF; (4) máximo 5 días hábiles tras la evaluación ordinaria;
     *      (5) menos de 2 solicitudes previas en esa asignatura.
     * POST: la solicitud existe en el sistema en estado "pendiente de evaluación" y
     *       el estudiante no supera 2 solicitudes en esa asignatura.
     */
    public Solicitud realizarSolicitud(Usuario u, String asignatura, LocalDate fechaEval,
                                       LocalDate fechaSol, String archivo) {
        pre(u != null && u.rol == Rol.ESTUDIANTE && u.activo && u.sesionIniciada,
                "debe ser un estudiante con cuenta activa y sesión iniciada");
        pre(asignatura != null && !asignatura.isBlank() && fechaEval != null && fechaSol != null
                && !fechaSol.isBefore(fechaEval), "datos obligatorios incompletos o fechas inconsistentes");
        pre(archivo != null && archivo.toLowerCase().endsWith(".pdf"),
                "la excusa debe adjuntarse en formato PDF");
        int dias = diasHabiles(fechaEval, fechaSol);
        pre(dias <= PLAZO_MAX_DIAS_HABILES,
                "fuera de plazo (" + dias + " días hábiles; máximo " + PLAZO_MAX_DIAS_HABILES + ")");
        pre(contarSolicitudes(u, asignatura) < MAX_SOLICITUDES_POR_ASIGNATURA,
                "ya existen " + MAX_SOLICITUDES_POR_ASIGNATURA + " solicitudes para esta asignatura");

        Solicitud s = new Solicitud(siguienteId++, u, asignatura.trim(), fechaEval, fechaSol, archivo);
        solicitudes.add(s);

        post(solicitudes.contains(s) && s.estado == Estado.PENDIENTE_DE_EVALUACION,
                "la solicitud debe quedar registrada en 'pendiente de evaluación'");
        post(contarSolicitudes(u, asignatura) <= MAX_SOLICITUDES_POR_ASIGNATURA,
                "no se pueden superar 2 solicitudes por asignatura");
        return s;
    }

    // ---------- Funcionalidad 2: Consultar estado de la solicitud ----------
    /**
     * PRE: (1) sesión iniciada; (2) la solicitud existe; (3) el usuario es el estudiante dueño o el director.
     * POST: devuelve el estado actual y la consulta no modifica la solicitud (solo lectura).
     */
    public Estado consultarEstado(Usuario u, int id) {
        pre(u != null && u.sesionIniciada, "el usuario debe tener sesión iniciada");
        Solicitud s = buscar(id);
        pre(s != null, "la solicitud #" + id + " no existe");
        pre(s.estudiante == u || u.rol == Rol.DIRECTOR,
                "solo el estudiante dueño o el director pueden consultarla");

        Estado antes = s.estado;
        Estado resultado = s.estado;
        post(resultado == s.estado && antes == s.estado, "la consulta no debe cambiar el estado");
        return resultado;
    }

    // ---------- Funcionalidad 3: Evaluar solicitud de supletorio ----------
    /**
     * PRE: (1) usuario director con sesión; (2) solicitud existente en "pendiente de evaluación";
     *      (3) no se puede aprobar una solicitud fuera de plazo (A ↔ excusa válida ∧ en plazo).
     * POST: estado actualizado ("pendiente de pago" o "Rechazada"); si se rechaza, calificación = 0;
     *       se envía exactamente un correo al estudiante.
     */
    public void evaluar(Usuario u, int id, boolean aprobar, String observacion) {
        pre(u != null && u.rol == Rol.DIRECTOR && u.sesionIniciada,
                "solo un director de programa con sesión iniciada puede evaluar");
        Solicitud s = buscar(id);
        pre(s != null, "la solicitud #" + id + " no existe");
        pre(s.estado == Estado.PENDIENTE_DE_EVALUACION, "la solicitud ya fue evaluada");
        boolean enPlazo = diasHabiles(s.fechaEvaluacion, s.fechaSolicitud) <= PLAZO_MAX_DIAS_HABILES;
        pre(!aprobar || enPlazo, "no se puede aprobar una solicitud fuera de plazo");

        int correosAntes = correos.size();
        if (aprobar) {
            s.estado = Estado.PENDIENTE_DE_PAGO;
        } else {
            s.estado = Estado.RECHAZADA;
            s.calificacion = 0.0;
        }
        correos.add("Para: " + s.estudiante.correo + " | Solicitud #" + s.id + " (" + s.asignatura + "): "
                + s.estado + (observacion == null || observacion.isBlank() ? "" : " | Obs: " + observacion));

        post(s.estado != Estado.PENDIENTE_DE_EVALUACION, "la solicitud debe quedar evaluada");
        post(aprobar || (s.calificacion != null && s.calificacion == 0.0),
                "una solicitud rechazada debe tener calificación 0");
        post(correos.size() == correosAntes + 1, "se debe notificar al estudiante por correo institucional");
    }
}
