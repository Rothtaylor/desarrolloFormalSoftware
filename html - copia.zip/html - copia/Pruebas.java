import java.time.LocalDate;

/** Casos de prueba iniciales (normal, límite, inválido). Ejecutar: java Pruebas */
public class Pruebas {
    static int total = 0, pasaron = 0;
    static final LocalDate EVAL = LocalDate.of(2026, 8, 26); // miércoles
    static final Usuario carlos = new Usuario("Carlos Pérez", "cperez@unipacifico.edu.co", Rol.ESTUDIANTE);
    static final Usuario maria = new Usuario("María Gómez", "mgomez@unipacifico.edu.co", Rol.ESTUDIANTE);
    static final Usuario director = new Usuario("Jorge Mina", "jmina@unipacifico.edu.co", Rol.DIRECTOR);

    /** n-ésimo día hábil después de la evaluación ordinaria. */
    static LocalDate hab(int n) {
        LocalDate d = EVAL;
        while (n > 0) {
            d = d.plusDays(1);
            if (SupletoriosService.esHabil(d)) n--;
        }
        return d;
    }

    /** Intenta registrar; devuelve el mensaje de error o null si se registró. */
    static String intento(SupletoriosService sv, Usuario u, String asig, int dias, String archivo) {
        try { sv.realizarSolicitud(u, asig, EVAL, hab(dias), archivo); return null; }
        catch (RuntimeException e) { return e.getMessage(); }
    }

    static String error(Runnable r) {
        try { r.run(); return null; } catch (RuntimeException e) { return e.getMessage(); }
    }

    static void verificar(String nombre, boolean cumple, String detalle) {
        total++;
        if (cumple) pasaron++;
        System.out.println((cumple ? "✔ " : "✖ ") + nombre + (detalle == null ? "" : "\n     → " + detalle));
    }

    public static void main(String[] args) {
        System.out.println("--- Realizar solicitud ---");
        SupletoriosService sv = new SupletoriosService();
        Solicitud s = sv.realizarSolicitud(carlos, "Estructuras de Datos", EVAL, hab(2), "excusa.pdf");
        verificar("Normal: 2 días hábiles -> 'pendiente de evaluación'",
                s.estado == Estado.PENDIENTE_DE_EVALUACION, null);

        sv = new SupletoriosService();
        verificar("Límite: 5.º día hábil (cruza fin de semana) se acepta",
                intento(sv, carlos, "Cálculo", 5, "a.pdf") == null, "fecha " + hab(5));
        String m = intento(sv, carlos, "Física", 6, "a.pdf");
        verificar("Límite: 6.º día hábil se rechaza", m != null, m);

        sv = new SupletoriosService();
        boolean dos = intento(sv, carlos, "Cálculo", 1, "a.pdf") == null && intento(sv, carlos, "Cálculo", 2, "a.pdf") == null;
        verificar("Límite: segunda solicitud de la asignatura se acepta", dos, null);
        m = intento(sv, carlos, "Cálculo", 3, "a.pdf");
        verificar("Límite: tercera solicitud de la asignatura se rechaza", m != null, m);

        m = intento(sv, carlos, "Física", 1, "excusa.docx");
        verificar("Inválido: archivo que no es PDF", m != null, m);
        m = intento(sv, carlos, "Física", 1, null);
        verificar("Inválido: sin archivo", m != null, m);
        m = intento(sv, carlos, "  ", 1, "a.pdf");
        verificar("Inválido: datos incompletos (asignatura vacía)", m != null, m);

        System.out.println("\n--- Consultar estado ---");
        sv = new SupletoriosService();
        s = sv.realizarSolicitud(carlos, "Estructuras de Datos", EVAL, hab(2), "excusa.pdf");
        verificar("Normal: el estudiante dueño consulta su solicitud",
                sv.consultarEstado(carlos, s.id) == Estado.PENDIENTE_DE_EVALUACION, null);
        sv.evaluar(director, s.id, true, "ok");
        verificar("Límite: tras evaluar, la consulta muestra el estado actualizado",
                sv.consultarEstado(carlos, s.id) == Estado.PENDIENTE_DE_PAGO
                        && sv.consultarEstado(director, s.id) == Estado.PENDIENTE_DE_PAGO, null);
        final SupletoriosService sv1 = sv; final int id1 = s.id;
        m = error(() -> sv1.consultarEstado(maria, id1));
        verificar("Inválido: otro estudiante no puede consultar", m != null, m);
        m = error(() -> sv1.consultarEstado(carlos, 999));
        verificar("Inválido: solicitud inexistente", m != null, m);

        System.out.println("\n--- Evaluar solicitud ---");
        sv = new SupletoriosService();
        s = sv.realizarSolicitud(carlos, "Estructuras de Datos", EVAL, hab(2), "excusa.pdf");
        sv.evaluar(director, s.id, true, "Excusa válida");
        verificar("Normal: aprobar -> 'pendiente de pago' y correo enviado",
                s.estado == Estado.PENDIENTE_DE_PAGO && sv.correos.size() == 1, sv.correos.get(0));

        sv = new SupletoriosService();
        s = sv.realizarSolicitud(carlos, "Cálculo", EVAL, hab(2), "excusa.pdf");
        sv.evaluar(director, s.id, false, "Excusa no válida");
        verificar("Normal: rechazar -> 'Rechazada', calificación 0 y correo enviado",
                s.estado == Estado.RECHAZADA && s.calificacion == 0.0 && sv.correos.size() == 1, sv.correos.get(0));

        sv = new SupletoriosService();
        Solicitud quinto = new Solicitud(1, carlos, "Física", EVAL, hab(5), "a.pdf");
        Solicitud sexto = new Solicitud(2, maria, "Física", EVAL, hab(6), "a.pdf");
        sv.solicitudes.add(quinto);
        sv.solicitudes.add(sexto);
        sv.evaluar(director, 1, true, "");
        verificar("Límite: la del 5.º día hábil puede aprobarse", quinto.estado == Estado.PENDIENTE_DE_PAGO, null);
        final SupletoriosService sv2 = sv;
        m = error(() -> sv2.evaluar(director, 2, true, ""));
        verificar("Límite: la del 6.º día hábil no puede aprobarse", m != null, m);

        sv = new SupletoriosService();
        s = sv.realizarSolicitud(carlos, "Cálculo", EVAL, hab(1), "a.pdf");
        final SupletoriosService sv3 = sv; final int id3 = s.id;
        m = error(() -> sv3.evaluar(carlos, id3, true, ""));
        verificar("Inválido: un estudiante intenta evaluar", m != null && s.estado == Estado.PENDIENTE_DE_EVALUACION, m);
        sv.evaluar(director, id3, false, "");
        m = error(() -> sv3.evaluar(director, id3, true, ""));
        verificar("Inválido: evaluar dos veces la misma solicitud", m != null && s.estado == Estado.RECHAZADA, m);

        System.out.println("\nResultado: " + pasaron + "/" + total + " casos superados");
    }
}
