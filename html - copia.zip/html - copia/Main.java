import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SupletoriosService servicio = new SupletoriosService();
        Usuario[] usuarios = {
                new Usuario("Carlos Pérez", "cperez@unipacifico.edu.co", Rol.ESTUDIANTE),
                new Usuario("María Gómez", "mgomez@unipacifico.edu.co", Rol.ESTUDIANTE),
                new Usuario("Jorge Mina", "jmina@unipacifico.edu.co", Rol.DIRECTOR)
        };
        Usuario actual = usuarios[0];
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Supletorios | Usuario: " + actual.nombre + " (" + actual.rol + ") ===");
            System.out.println("1. Realizar solicitud   2. Consultar estado   3. Evaluar solicitud");
            System.out.println("4. Cambiar de usuario   0. Salir");
            String opcion = leer(sc, "Opción: ");

            try {
                switch (opcion) {
                    case "1" -> {
                        String asignatura = leer(sc, "Asignatura: ");
                        LocalDate fEval = LocalDate.parse(leer(sc, "Fecha evaluación ordinaria (AAAA-MM-DD): "));
                        LocalDate fSol = LocalDate.parse(leer(sc, "Fecha de solicitud (AAAA-MM-DD): "));
                        String archivo = leer(sc, "Archivo de la excusa (ej. excusa.pdf): ");
                        Solicitud s = servicio.realizarSolicitud(actual, asignatura, fEval, fSol, archivo);
                        System.out.println("✔ Solicitud #" + s.id + " registrada. Estado: " + s.estado);
                    }
                    case "2" -> {
                        int id = Integer.parseInt(leer(sc, "Número de solicitud: "));
                        System.out.println("✔ Estado actual: " + servicio.consultarEstado(actual, id));
                    }
                    case "3" -> {
                        int id = Integer.parseInt(leer(sc, "Número de solicitud: "));
                        boolean aprobar = leer(sc, "¿Aprobar? (s = aprobar, n = rechazar): ").equalsIgnoreCase("s");
                        String obs = leer(sc, "Observaciones: ");
                        servicio.evaluar(actual, id, aprobar, obs);
                        System.out.println("✔ Decisión registrada.");
                        System.out.println("✉ " + servicio.correos.get(servicio.correos.size() - 1));
                    }
                    case "4" -> {
                        for (int i = 0; i < usuarios.length; i++) {
                            System.out.println((i + 1) + ". " + usuarios[i].nombre + " (" + usuarios[i].rol + ")");
                        }
                        actual = usuarios[Integer.parseInt(leer(sc, "Usuario: ")) - 1];
                    }
                    case "0" -> {
                        System.out.println("Saliendo del programa...");
                        sc.close();
                        return;
                    }
                    default -> System.out.println("Opción inválida.");
                }
            } catch (IllegalArgumentException | IllegalStateException | DateTimeParseException
                     | ArrayIndexOutOfBoundsException e) {
                System.out.println("✖ " + e.getMessage());
            }
        }
    }

    private static String leer(Scanner sc, String texto) {
        System.out.print(texto);
        return sc.nextLine().trim();
    }
}
